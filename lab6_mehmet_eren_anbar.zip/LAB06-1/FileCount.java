import java.io.File;
import java.util.Arrays;

public class FileCount {
    public static void main(String[] args) {
        System.out.println(fun1("/Users/erenanbar/Desktop/testA"));
        System.out.println(fun2("/Users/erenanbar/Desktop/testA"));
    }
    public static int getFilesCount(File file) {
        File[] files = file.listFiles();
        int count = 0;
        for (File f : files)
          if (f.isDirectory())
            count += getFilesCount(f);
          else
            count++;
      
        return count;
      }
    public static int fun1(String pathname){
        File d = new File(pathname);
        return getFilesCount(d);
    }
    public static int fun2(String pathname){
        File d = new File(pathname);
        return countFiles(d.listFiles());
    }

    public static int countFiles(File[] files) {
        if (files.length == 0){
            return 0;
        }
        else if(files.length == 1 && files[0].isFile()){
            return 1;
        }
        else if (files.length == 1 && files[0].isDirectory()){
            return countFiles(files[0].listFiles());
        }
        else{                            
            File firstFile = files[0];
            File[] shorterFiles = new File[files.length-1];
            for(int i = 0; i < files.length-1;i++){
                shorterFiles[i] = files[i+1];
            }
            if (firstFile.isFile()){
                return 1 + countFiles(shorterFiles);
            }
            else {
                return countFiles(firstFile.listFiles()) + countFiles(shorterFiles) ;
            }
        }
    }                  

}
 