import java.util.Iterator;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collection;

public class IntBagAL{

    private ArrayList<Integer> bag;

    public IntBagAL (){
        this.bag = new ArrayList<Integer>();
    }
    public void add(int num){ 
        if (num >= 0){
            bag.add(num);
        }
        else{System.out.println("Enter a positive value...");}
    }
    public boolean contains(int num){
        return bag.contains(num);
    }
    public void remove(Object element){
        bag.remove(element);
    }
    public int size(){
        return bag.size();
    }
    public Iterator getIterator(){
        Iterator<Integer> i = bag.iterator();
        return i;
    }
}


