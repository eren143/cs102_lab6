import java.util.Iterator;
import java.util.TreeSet;

public class IntBagTS {
    private TreeSet<Integer> bag;

    public IntBagTS (){
        this.bag = new TreeSet<Integer>();
    }
    public void add(int num){ 
        if (num >= 0){
            bag.add(num);
        }
        else{System.out.println("Enter a positive value...");}
    }
    public boolean contains(int num){
        return bag.contains(num);
    }
    public void remove(Object element){
        bag.remove(element);
    }
    public int size(){
        return bag.size();
    }
    public Iterator getIterator(){
        Iterator<Integer> i = bag.iterator();
        return i;
    }
}
