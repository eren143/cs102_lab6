import java.util.LinkedList;
import java.util.Scanner;

public class extra {
    /*
     * Implement a to-do list console application using the LinkedList 
    class. The user should be able to add string items to the list, remove a 
    selected item and move a selected item to a different position. Display 
    the options and get the user's selection. For add option, the user 
    should input the desired string that will be added to the end of the 
    list. For the remove option, get the item number to remove from the 
    list; the input integer should be within the current range. For the move 
    option, first, get the item to move its position, then get the new order 
    for this item. Both integers should be within the current range.
     */
    public static void main(String[] args){
        int selection;
        Scanner scan = new Scanner(System.in);
        boolean quit = false;
        LinkedList<String> todoList = new LinkedList<>();



        do{
            System.out.println("1. Add item to list");
            System.out.println("2. Remove a selected item from the list");
            System.out.println("3. move item to another position");
            System.out.println("4. quit");

            selection = scan.nextInt();
            if (selection == 1){
                System.out.print("Enter the item to add: ");
                String item = scan.next();
                todoList.addLast(item);
                System.out.println("New todo list: "+todoList.toString());
            }
            else if (selection == 2){
                System.out.println("enter the item number to remove: ");
                int itemNumber = scan.nextInt();
                if (itemNumber >= 0 && itemNumber < todoList.size())
                todoList.remove(itemNumber);
                System.out.println("New todo list: "+todoList.toString());
            }
            else if (selection == 3){
                System.out.print("enter the item to be moved: ");
                int itemNumberOld = scan.nextInt();
                if (itemNumberOld >= 0 && itemNumberOld < todoList.size()){
                    String itemToBeMoved = todoList.get(itemNumberOld);
                    System.out.print("enter where to move the item: ");
                    int itemNumberNew = scan.nextInt();
                    if (itemNumberNew >= 0 && itemNumberNew < todoList.size())
                    todoList.remove(itemNumberOld);
                    todoList.add(itemNumberNew, itemToBeMoved);
                }

                System.out.println("New todo list: "+todoList.toString());
                }
            else if (selection == 4){quit = true;}

            }while(!quit);

        }
    }



