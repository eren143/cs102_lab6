import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;



public class app {
    public static void main(String[] args) {
        int[] randomNums = new int[1000000];
        Random rand = new Random();
        Iterator iter;
        long begin,end,time;
        long[] addingMillonElements = new long[4];
        long[] insertOneElement = new long[4];
        long[] containElement = new long[4];
        long[] deleteElement = new long[4];
        long[] traverseElements = new long[4];



        for (int i = 0; i < randomNums.length;i++){
            randomNums[i] = rand.nextInt(1000000);
        }
        IntBagAL intBagAL = new IntBagAL(); //0
        IntBagLL intBagLL = new IntBagLL(); //1
        IntBagTS intBagTS = new IntBagTS(); //2
        IntBagHS intBagHS = new IntBagHS(); //3
        

        begin = System.nanoTime();
        //Total time taken to insert all 1 million integers to intBagAL
        for (int el : randomNums){
            intBagAL.add(el);
        }
        end = System.nanoTime();
        time = end - begin;
        addingMillonElements[0] = time;

        begin = System.nanoTime();
        //Time taken to insert one additional element 
        intBagAL.add(34);
        end = System.nanoTime();             
        time = end - begin;
        insertOneElement[0] = time;

        begin = System.nanoTime();
        //The average time taken to check if a random integer is contained (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagAL.contains(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        containElement[0] = time;


        begin = System.nanoTime();
        //The average time taken to delete a random element from the original 1 million integers (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagAL.remove(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        deleteElement[0] = time;

        begin = System.nanoTime();
        //Time taken to traverse the collection using an iterator
        iter = intBagAL.getIterator();
        while (iter.hasNext()){
            iter.next();
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        traverseElements[0] = time;
        
        //*************************************************


        
        begin = System.nanoTime();
        //Total time taken to insert all 1 million integers to intBagAL
        for (int el : randomNums){
            intBagLL.add(el);
        }
        end = System.nanoTime();
        time = end - begin;
        addingMillonElements[1] = time;

        begin = System.nanoTime();
        //Time taken to insert one additional element 
        intBagLL.add(34);
        end = System.nanoTime();             
        time = end - begin;
        insertOneElement[1] = time;

        begin = System.nanoTime();
        //The average time taken to check if a random integer is contained (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagLL.contains(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        containElement[1] = time;


        begin = System.nanoTime();
        //The average time taken to delete a random element from the original 1 million integers (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagLL.remove(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        deleteElement[1] = time;

        begin = System.nanoTime();
        //Time taken to traverse the collection using an iterator
        iter = intBagLL.getIterator();
        while (iter.hasNext()){
            iter.next();
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        traverseElements[1] = time;
        
        //*************************************************





        begin = System.nanoTime();
        //Total time taken to insert all 1 million integers to intBagAL
        for (int el : randomNums){
            intBagTS.add(el);
        }
        end = System.nanoTime();
        time = end - begin;
        addingMillonElements[2] = time;

        begin = System.nanoTime();
        //Time taken to insert one additional element 
        intBagTS.add(34);
        end = System.nanoTime();             
        time = end - begin;
        insertOneElement[2] = time;

        begin = System.nanoTime();
        //The average time taken to check if a random integer is contained (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagTS.contains(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        containElement[2] = time;


        begin = System.nanoTime();
        //The average time taken to delete a random element from the original 1 million integers (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagTS.remove(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        deleteElement[2] = time;

        begin = System.nanoTime();
        //Time taken to traverse the collection using an iterator
        iter = intBagTS.getIterator();
        while (iter.hasNext()){
            iter.next();
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        traverseElements[2] = time;
        //*************************************************



        begin = System.nanoTime();
        //Total time taken to insert all 1 million integers to intBagAL
        for (int el : randomNums){
            intBagHS.add(el);
        }
        end = System.nanoTime();
        time = end - begin;
        addingMillonElements[3] = time;

        begin = System.nanoTime();
        //Time taken to insert one additional element 
        intBagHS.add(34);
        end = System.nanoTime();             
        time = end - begin;
        insertOneElement[3] = time;

        begin = System.nanoTime();
        //The average time taken to check if a random integer is contained (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagHS.contains(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        containElement[3] = time;


        begin = System.nanoTime();
        //The average time taken to delete a random element from the original 1 million integers (average of 100 tests)
        for (int i = 0; i <100; i++){
            int randomNum = rand.nextInt(1000000);
            intBagHS.remove(randomNum);
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        deleteElement[3] = time;

        begin = System.nanoTime();
        //Time taken to traverse the collection using an iterator
        iter = intBagHS.getIterator();
        while (iter.hasNext()){
            iter.next();
        }
        end = System.nanoTime(); 
        time = (end - begin)/100;
        traverseElements[3] = time;
        //*************************************************
        
        for (int i = 0; i < 4; i++){
            System.out.print(addingMillonElements[i]+", ");
            System.out.print(insertOneElement[i]+", ");
            System.out.print(containElement[i]+", ");
            System.out.print(deleteElement[i]+", ");
            System.out.print(traverseElements[i]+"\n");
        }
         



    }
}
