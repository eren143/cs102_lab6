import java.util.ArrayList;
import java.util.Arrays;
public class RecursiveMethods{
    static final char[] nonVowels = {'Z', 'B', 'T', 'G', 'H'};

    public static void main(String[] args) {
        //generateBinary(4);

        System.out.println(countNonVowels("CS102 is a good course"));
    
    }

    //Count the length of the string that is given using recursion.
    public static int countLength(String s){
        //base case
        if (s.length()==1){return 1;}
        else {
            String shorterString = s.substring(1);
            return 1 + countLength(shorterString);
        }
    }
    //Find the number of non-vowels in a given array of characters/string using recursion. 
    //We do not care about the case(upper or lower) in this problem.
    public static int countNonVowels(String s){
        s = s.toLowerCase();
        if (s.length()==0){
            return 0;
        }
        else if (s.length() == 1 && isNonVowel(s.charAt(0))){
            return 1;
        }
    
        else {
            char c = s.charAt(0);
            String shorterString = s.substring(1);
            if (isNonVowel(c)&& Character.isLetter(c)) {
                return(1 + countNonVowels(shorterString));
            }
            else {
                return(countNonVowels(shorterString));
            }
        }
    }
    public static boolean isNonVowel(char c){
        if ((c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')){
            return false;
        }
        else {return true;}
    }

    public static void recursiveBinary(int n, char[] ch, int k){
        if (n == k){
            System.out.println(Arrays.toString(ch));
        }
        else {
            if (ch[k-1] == '0'){
                ch[k] = '1';
                recursiveBinary(n,ch,k+1);
                ch[k] = '0';
                recursiveBinary(n,ch,k+1);
            }
            else if (ch[k-1] == '1'){
                ch[k] = '0';
                recursiveBinary(n,ch,k+1);
            }
        }
    }
    public static void generateBinary(int len){
        char[] ch = new char[len];
        ch[0] = '0';
        recursiveBinary(len, ch,1);
        ch[0] = '1';
        recursiveBinary(len, ch,1);
    }
    

}            